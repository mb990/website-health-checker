<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProjectRoleController extends Controller
{
    //
}
