@extends('layouts.app')

@section('title')
    Invitation accepted
@endsection

@section('content')

    <h1>You are now team member on project {{$project->name}}</h1>

@endsection
