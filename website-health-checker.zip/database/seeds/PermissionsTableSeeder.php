<?php

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class PermissionsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
//        $permissions = ['delete project', 'delete user', 'activate project', 'activate user', 'deactivate project',
//                        'deactivate user', 'edit project', 'add url', 'edit url', 'delete url', 'invite member',
//                        'view project'
//        ];
//
//        foreach ($permissions as $permission) {
//            $permission = Permission::create(['name' => $permissions[0]]);
//            array_shift($permissions);
//        }
    }
}
