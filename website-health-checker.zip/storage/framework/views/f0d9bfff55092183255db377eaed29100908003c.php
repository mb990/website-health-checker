<?php $__env->startSection('title'); ?>
    New project
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">
        <div class="col-sm-4 col-md-4 col-lg-4">
            <div class="panel panel-default">
                <div class="panel-heading text-center">

                    <h3 class="text-info">New project</h3>

                </div><br>

                <div class="panel-body">

                    <form action="<?php echo e(route('store.project')); ?>" method="POST" xmlns="http://www.w3.org/1999/html">
                        <?php echo csrf_field(); ?>
                        <label for="project_name">Name</label>
                        <input class="form-control" name="name" type="text" id="project_name" placeholder="Project name"><br>

                        <button class="btn btn-primary" type="submit">Submit</button>
                    </form>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views/projects/create.blade.php ENDPATH**/ ?>