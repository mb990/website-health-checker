<?php $__env->startSection('title'); ?>
    Project invitation
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(auth()->guard()->check()): ?>

        <div class="row">

            <div class="col-md-12 text-center">

                <h1>Hello <?php echo e(ucfirst($user->first_name)); ?> <?php echo e(ucfirst($user->last_name)); ?></h1><br>;

                <h2><?php echo e(ucfirst($project->creator->first_name)); ?> <?php echo e(ucfirst($project->creator->last_name)); ?> invited you to
                    join his project <?php echo e(ucfirst($project->name)); ?></h2><br>

                <form action="<?php echo e(route('accept', $token)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-success">Accept</button>

                </form>

                <form action="<?php echo e(route('reject', $token)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button class="btn btn-danger">Reject</button>

                </form>

            </div>

        </div>

    <?php endif; ?>

    <?php if(auth()->guard()->guest()): ?>

        <div class="row">

            <div class="col-md-12 text-center">

                <h1>Hello</h1><br>;

                <h2><?php echo e(ucfirst($project->creator->first_name)); ?> <?php echo e(ucfirst($project->creator->last_name)); ?> invited you to
                    join his project <?php echo e(ucfirst($project->name)); ?></h2><br>

                <form action="<?php echo e(route('accept.guest', $token)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-success">Accept</button>

                </form>

                <form action="<?php echo e(route('reject', $token)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button class="btn btn-danger">Reject</button>

                </form>

            </div>

        </div>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views/teams/view-invitation.blade.php ENDPATH**/ ?>