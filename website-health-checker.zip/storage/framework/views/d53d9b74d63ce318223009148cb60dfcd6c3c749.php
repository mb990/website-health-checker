<?php $__env->startSection('title'); ?>
    View project
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row justify-content-center">

        <h3 class="text-info">View project</h3>
<!--        --><?php //use Illuminate\Support\Facades\Http; ?>



<!--        --><?php //$urls = \App\ProjectUrl::all(); dd($urls); ?>

    </div>

    <br>

    <div class="row text-center">

        <div class="col-md-12">

            <p class="lead">Name: <?php echo e($project->name); ?></p>

            
            

            <p class="lead">URLS:</p>

        </div>

        <div class="row">

            <?php if($project->urls): ?>

                <?php $__currentLoopData = $project->urls; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-md-8">

                        <a href="/projects/<?php echo e($project->slug); ?>/<?php echo e($url->id); ?>/checks"><p class="lead"><?php echo e($url->url); ?></p></a>
                        <hr>

                    </div>

                    <?php if(auth()->guard()->check()): ?>

                        <?php if(auth()->user()->id === $project->user_id): ?>

                            <div class="col-md-2">

                                <a href="/projects/<?php echo e($project->slug); ?>/<?php echo e($url->id); ?>/edit">
                                    <button class="btn btn-success" type="submit">Edit</button>
                                </a>

                            </div>

                            <div class="col-md-2">

                                <form action="<?php echo e(action('ProjectUrlController@delete', $url->id)); ?>" method="POST"
                                      xmlns="http://www.w3.org/1999/html">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>

                                    <button class="btn btn-danger" type="submit">Delete</button>
                                </form>

                            </div>

                        <?php endif; ?>

                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>

                <p>No urls for this project.</p>

            <?php endif; ?>

        </div>

    </div>

    <?php if(auth()->guard()->check()): ?>

        <?php if(auth()->user()->id === $project->user_id): ?>

            <div class="row text-center">

                <div class="col-md-12">

                    <form action="<?php echo e(action('ProjectUrlController@store', $project->slug)); ?>" method="POST"
                          xmlns="http://www.w3.org/1999/html">
                        <?php echo csrf_field(); ?>

                        <input name="url" type="text" placeholder="Add url here">

                        <button class="btn btn-primary" type="submit">Add</button>
                    </form>

                    <br>

                    <form action="<?php echo e(action('ProjectController@delete', $project->slug)); ?>" method="POST"
                          xmlns="http://www.w3.org/1999/html">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>

                        <button class="btn btn-danger" type="submit">Delete project</button>
                    </form>

                </div>

            </div>

        <?php endif; ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views\projects\show-single.blade.php ENDPATH**/ ?>