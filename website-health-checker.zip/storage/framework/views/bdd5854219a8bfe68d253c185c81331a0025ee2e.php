<?php $__env->startSection('title'); ?>
    Invitation accepted
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <h1>You are now team member on project <?php echo e($project->name); ?></h1>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views/teams/accepted-invitation.blade.php ENDPATH**/ ?>