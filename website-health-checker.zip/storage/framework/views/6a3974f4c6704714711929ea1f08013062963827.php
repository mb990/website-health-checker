<?php $__env->startSection('title'); ?>
    Projects
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="jumbotron">
        <h1 class="text-center">Projects</h1>
    </div>

    <?php if(count($projects)): ?>

        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="row text-center">

                <div class="col-md-4">


                        <p class="text-secondary"><strong>Name:</strong> <?php echo e(ucfirst($project->name)); ?></p>


                        <p class="text-secondary"><strong>Creator:</strong> <?php echo e($project->creator->first_name); ?> <?php echo e($project->creator->last_name); ?></p>


                </div>

                <div class="col-md-4"><br>

                    <?php if($project->active): ?>

                        <form action="<?php echo e(route('deactivate.project', $project->slug)); ?>" method="POST">

                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <input class="btn btn-danger" type="submit" value="Deactivate">

                        </form>

                    <?php else: ?>

                        <form action="<?php echo e(route('activate.project', $project->slug)); ?>" method="POST">

                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <input class="btn btn-success " type="submit" value="Activate">

                        </form>

                    <?php endif; ?>

                </div>

                <div class="col-md-4"><br>

                    <form action="<?php echo e(route('destroy.project', $project->slug)); ?>" method="POST">

                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <input class="btn btn-danger" type="submit" value="Delete">

                    </form>

                </div>

            </div>

            <hr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php else: ?>

        <p class="p-3 mb-2 bg-warning text-dark">No projects at the moment.</p>

    <?php endif; ?>

    <div class="row justify-content-center">

        <?php echo e($projects->links()); ?>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views/admin/projects/all.blade.php ENDPATH**/ ?>