<header>
    <h2>Website health checker</h2>
</header>
<?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views\includes\header.blade.php ENDPATH**/ ?>