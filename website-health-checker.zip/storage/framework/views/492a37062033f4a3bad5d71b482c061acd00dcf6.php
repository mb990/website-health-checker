<?php $__env->startSection('title'); ?>
    Users
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="jumbotron">
        <h1 class="text-center">Users</h1>
    </div>

    <?php if(count($users)): ?>

        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="row text-center">

                <div class="col-md-4">



                        <p class="text-secondary"><strong>User:</strong> <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?></p>



                </div>

                <div class="col-md-4">

                    <?php if($user->active): ?>

                        <form action="<?php echo e(route('deactivate.user', $user->slug)); ?>" method="POST">

                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <input class="btn btn-danger" type="submit" value="Deactivate">

                        </form>

                    <?php else: ?>

                        <form action="<?php echo e(route('activate.user', $user->slug)); ?>" method="POST">

                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <input class="btn btn-success " type="submit" value="Activate">

                        </form>

                    <?php endif; ?>

                </div>

                <div class="col-md-4">

                    <form action="<?php echo e(route('destroy.user', $user->slug)); ?>" method="POST">

                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <input class="btn btn-danger" type="submit" value="Destroy">

                    </form>

                </div>

            </div>

            <hr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php else: ?>

        <p class="p-3 mb-2 bg-warning text-dark">No users at the moment.</p>

    <?php endif; ?>

    <div class="row justify-content-center">

        <?php echo e($users->links()); ?>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views/admin/users/all.blade.php ENDPATH**/ ?>