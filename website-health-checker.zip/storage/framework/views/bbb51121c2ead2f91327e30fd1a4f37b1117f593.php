<?php $__env->startSection('title'); ?>
    Invite member
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row text-center justify-content-center">

        <div class="col-md-6">

            <h1>Invite member to your team</h1>

            <form action="<?php echo e(route('process', $project->slug)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <select id="user" name="user">

                    <option disabled selected value> -- choose user --</option>

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option class="form-control" name="user"
                                value="<?php echo e($user->id); ?>"><?php echo e(ucfirst($user->first_name)); ?> <?php echo e(ucfirst($user->last_name)); ?></option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select><br><br>

                <h3>Invite guest</h3>

                <input class="form-control" type="text" name="guest" placeholder="Enter email"><br>

                <button class="btn btn-success" type="submit" value="Submit">Submit</button>

            </form>

        </div>

    </div>

    <?php if($errors->any()): ?>
        <h4><?php echo e($errors->first()); ?></h4>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views/teams/invite.blade.php ENDPATH**/ ?>