<?php $__env->startSection('title'); ?>
    Edit url
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(auth()->guard()->check()): ?>

        <?php if(auth()->user()->id != $url->project->user_id): ?>

            <h1>You dont have permissions.</h1>

        <?php else: ?>

            <div class="row text-center">

                <div class="col-md-12">

                    <h2>Edit url</h2>

                </div>

            </div>

            <div class="row text-center">
                <div class="offset-4 col-md-4">
                    <form action="<?php echo e(route('update.projectUrl', $url->id)); ?>" method="POST"
                          xmlns="http://www.w3.org/1999/html">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>

                        <label class="form-control" for="check_frequency_id">Change check frequency</label>
                        <select class="form-control" name="check_frequency_id" id="check_frequency_id">
                            <?php $__currentLoopData = $frequencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frequency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php if($frequency->id === $url->check_frequency_id): ?> selected
                                        <?php endif; ?> value=<?php echo e($frequency->id); ?>><?php echo e($frequency->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select><br>

                        <button class="btn btn-success" type="submit">Change</button>
                    </form>

                </div>

            </div>

        <?php endif; ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views/projects/edit-url.blade.php ENDPATH**/ ?>