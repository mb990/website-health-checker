<?php $__env->startSection('title'); ?>
    Checks for this url
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <h3 class="text-center"><?php echo e($url->url); ?></h3>

    <div class="row">

        <div class="col-md-6">

            <?php echo $chart->container(); ?>


            <?php echo $chart->script(); ?>


        </div>

        <div class="col-md-6">

            <?php echo $chart2->container(); ?>


            <?php echo $chart2->script(); ?>


        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views/projects/url-checks.blade.php ENDPATH**/ ?>