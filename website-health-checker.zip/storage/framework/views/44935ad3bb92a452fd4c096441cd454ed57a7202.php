<?php $__env->startSection('title'); ?>
    Edit project
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(auth()->guard()->check()): ?>

        <?php if(auth()->user()->id != $setting->user_id): ?>

            <h1>You dont have permissions.</h1>

        <?php else: ?>

            <div class="row justify-content-center">
                <div class="col-sm-4 col-md-4 col-lg-4">
                    <div class="panel panel-default">
                        <div class="panel-heading text-center">

                            <h3 class="text-info">Edit your notification settings</h3>

                        </div><br>

                        <div class="panel-body">

                            <form action="<?php echo e(action('NotificationSettingController@update', $setting->id)); ?>" method="POST" xmlns="http://www.w3.org/1999/html">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>

                                <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label for="active"><?php echo e($setting->type->name); ?></label>
                                    <input class="form-control" name="active" type="text" id="active" placeholder="Project name" value="<?php echo e($project->name); ?>"><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <button class="btn btn-primary" type="submit">Submit</button>
                            </form>

                        </div>
                    </div>
                </div>
            </div>

        <?php endif; ?>

    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views\notification-settings\settings.blade.php ENDPATH**/ ?>
