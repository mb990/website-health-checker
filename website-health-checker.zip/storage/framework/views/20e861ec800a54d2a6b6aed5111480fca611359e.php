<?php $__env->startSection('title'); ?>
    Checks for this url
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php $__currentLoopData = $checks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <p class="lead">Time: <?php echo e($check->created_at); ?></p>
        <p class="lead">Response status: <?php echo e($check->response_code); ?></p>
        <p class="lead">Response time: <?php echo e($check->response_time / 1000); ?> seconds</p><hr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views\projects\url-checks.blade.php ENDPATH**/ ?>