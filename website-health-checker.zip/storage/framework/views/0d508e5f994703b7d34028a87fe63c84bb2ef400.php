<?php $__env->startSection('title'); ?>
    Projects
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    

    <div class="jumbotron">
        <h1 class="text-center">Projects</h1>
    </div>

    <div class="row justify-content-center">

        <h2 class="text-primary">Projects</h2>

    </div><br><br><br>

    <div class="row">

        <?php if(count($projects)): ?>

            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-md-4">

                    <div class="row">

                        <div class="col-md-8">

                            <p class="lead">Name:</p>

                            <a href="/projects/<?php echo e($project->slug); ?>">

                                <p class="lead"><?php echo e(ucfirst($project->name)); ?></p>

                            </a>

                        </div>

                        <?php if(auth()->guard()->check()): ?>

                            <div class="float-right col-md-4">

                                <?php if(auth()->user()->id === $project->user_id): ?>

                                   <br><label class="btn btn-success">my</label>

                                <?php endif; ?>

                            </div>

                        <?php endif; ?>

                    </div>

                    <hr>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php else: ?>

            <p class="lead">No projects.</p>

        <?php endif; ?>

    </div>

    <div class="row justify-content-center">

        <?php echo e($projects->links()); ?>


    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views\projects\show-all.blade.php ENDPATH**/ ?>