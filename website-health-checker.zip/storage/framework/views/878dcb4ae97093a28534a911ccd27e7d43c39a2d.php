<?php $__env->startSection('title'); ?>
    Project members
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <h1 class="text-center">Project members</h1><br>

    <?php if(count($members)): ?>

        <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="row text-center">

                <div class="col-md-4 <?php if($project->creator->id == $member->id): ?> lead <?php endif; ?>">

                    <?php echo e(ucfirst($member->first_name)); ?> <?php echo e(ucfirst($member->last_name)); ?>


                </div>

                <?php if($project->creator->id == auth()->user()->id): ?>

                    <?php if($member->id != $project->creator->id): ?>

                        <div class="col-md-4">

                            <form action="<?php echo e(route('remove.member', [$project->slug, $member->slug])); ?>">

                                <button class="btn btn-danger">Remove</button>

                            </form>

                        </div>

                    <?php endif; ?>

                <?php endif; ?>

            </div><hr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views/teams/project-members.blade.php ENDPATH**/ ?>