<footer class="footer mt-auto py-3">
    <div class="container background-color">
        <div class="row">
            <div class="col-md-12 text-center">
                <span><strong>Best Design Ever</strong></span>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12 text-center">
                <span><strong><?php echo e(date('Y')); ?></strong></span>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views/includes/footer.blade.php ENDPATH**/ ?>