<?php $__env->startSection('title'); ?>
    Homepage
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">

        <div class="offset-4 col-md-6">

            <h1>Hello</h1>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views\welcome.blade.php ENDPATH**/ ?>