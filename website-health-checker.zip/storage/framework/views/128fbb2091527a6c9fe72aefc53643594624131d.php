<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="row text-center">

        <div class="col-md-8">

            <h2>My created projects</h2>

            <?php if(count($projects)): ?>

                <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <a href="/projects/<?php echo e($project->slug); ?>"><p class="lead"><?php echo e($project->name); ?></p></a>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>

                You dont have projects.

            <?php endif; ?>

        </div>

        <div class="col-md-4">

            <a href="/projects/create/new"><button class="btn btn-primary">New project</button></a>

            <a href="/settings/<?php echo e(auth()->user()->slug); ?>"><button class="btn btn-primary">Global notification settings</button></a>

        </div>

    </div><br><hr>

    <div class="row text-center">

        <div class="col-md-8">

            <h2>Projects i joined</h2>

            <?php if(count($joinedProjects)): ?>

                <?php $__currentLoopData = $joinedProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $joinedProject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <a href="/projects/<?php echo e($joinedProject->slug); ?>"><p class="lead"><?php echo e($joinedProject->name); ?></p></a>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php else: ?>

                You didn't join any project.

            <?php endif; ?>

        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\website-health-checker\resources\views/dashboard.blade.php ENDPATH**/ ?>